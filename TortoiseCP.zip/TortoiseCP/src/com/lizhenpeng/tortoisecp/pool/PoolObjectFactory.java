package com.lizhenpeng.tortoisecp.pool;

/**
 * 池中缓存对象的接口
 * 定义对象的生命周期方法
 * @author 出门左转
 */
public interface PoolObjectFactory <T> {
	
	/**
	 * 对象池调用此方法生产对象
	 * @return
	 */
	public abstract T createObject();
	
	/**
	 * 验证对象的有效性
	 */
	public boolean validateObject(T object);
	
	/**
	 * 销毁对象
	 */
	public void destoryObject(T object);
	
	/**
	 * 将对象返回到缓存池
	 * @param object
	 */
	public void returnPoolObject(T object);
	
}
