package com.lizhenpeng.tortoisecp.pool;

import java.util.Iterator;
import java.util.LinkedList;
import java.util.Timer;
import java.util.TimerTask;

/**
 * 缓存池
 * @author 出门左转
 */
public class TortoisePool<T> {
	
	/**
	 * 缓存池的默认最大容量为50
	 */
	private static int poolMaximumNumber = 50;

	/**
	 * 缓存池中空闲对象的最大数量 显示空闲对象的最大数量
	 * 当并发较低时缓存空闲对象数量较多时会造成资源浪费
	 */
	private static int MaximumIdleNumber = 20;

	/**
	 * 缓存池中空闲对象的最小数量 
	 * 缓存池中缓存空闲对象可以在并发提高时减少创建对象花费的时间
	 */
	private static int MinimumIdleNumber = 0;

	/**
	 * 缓存池中借出对象的数量 借出的对象数量与总容量的关系如下 
	 * LoanNumber + AvailableNumber <= MaxmumSize
	 */
	private static int LoanNumber = 0;
	
	/**
	 * 缓存池当前可用的"池"对象数量(未被借出使用)
	 * 空闲对象可以保证在并发变高时减少创建对象花费的
	 * AvailableNumber + LoanNumber <= MaxmumSize
	 */
	private static int AvailableNumber = 0;

	/**
	 * 定义缓存池资源耗尽时执行的策略 缓存池资源耗尽时直接失败
	 */
	private static final int EXHAUSTED_FAIL = 0;

	/**
	 * 定义缓存池资源耗尽时执行的策略 缓存池资源耗尽时继续增长
	 */
	private static final int EXHAUSTED_GROW = 1;

	/**
	 * 定义缓存池资源耗尽时执行的策略 缓存池资源耗尽时直接失败
	 * 
	 */
	private static final int EXHAUSTED_BLOCK = 2;

	/**
	 * 定义缓存池资源耗尽时执行的策略 
	 * 缓存池资源耗尽时线程阻塞指定的时间
	 * 线程如果被唤醒之后依然没有获取资源,抛出异常
	 */
	private static int WHEN_EXHAUSTED_STRATEGY = EXHAUSTED_BLOCK;

	/**
	 * 定义阻塞模式下的线程超时时间
	 * 默认为-1,表示线程不超时,直到被唤醒
	 */
	private static long WAIT_TIME = -1;

	/**
	 * 线程池状态标识 
	 * false表示线程池当前正在运行
	 * true表示线程池已经关闭
	 */
	private static boolean ISCLOSE = false;

	/**
	 * 清除空闲资源标识,默认开启清除线程
	 */
	private static boolean EVICTOR_WORK = true;

	/**
	 * 闲置资源存活时间 
	 * 默认存活时间为5分中,超过存活时间即被清除
	 */
	private static int IDLE_RESOURCE_EXIST_TIME = 1000 * 60 * 5;

	/**
	 * 驱逐线程默认运行的时间间隔为5分钟
	 */
	private static int EVICTOR_WORK_lINTERVAL = 1000 * 60 * 5;
	
	/**
	 * 对象借出时候检测对象是否可用 并发较高时,使用此功能会影响性能
	 */
	private static boolean checkOnBorrow = true;

	/**
	 * 对象归还到池中时检测对象是否可用 并发交高时,使用此功能会影响性能
	 */
	private static boolean checkOnReturn =true;

	/**
	 * 池对象工厂 缓存池通过调用工厂创建、验证、销毁对象
	 */
	private PoolObjectFactory<T> objectFactory;
	
	/**
	 * 驱逐线程定时器
	 */
	private Timer procurator;

	/**
	 * 缓存池 缓存池默认使用栈进行实现
	 */
	private LinkedList<Entity<T>> _pool = new LinkedList<Entity<T>>();

	/**
	 * 等待队列 线程获取资源之前需要进行排队
	 */
	private LinkedList<Session<T>> _waitQueue = new LinkedList<>();

	/**
	 * 默认构造方法
	 * 需要传入PoolObjectFactory
	 * 池中默认不会初始化一定的对象,根据请求自动创建
	 * @param poolObjectFactory
	 */
	public TortoisePool(PoolObjectFactory<T> poolObjectFactory) {
		this(poolObjectFactory,PoolConfig.getDefaultConfig());
	}
	
	/**
	 * 使用池配置对象初始化对象池s
	 * @param poolObjectFactory
	 * @param config
	 */
	public TortoisePool(PoolObjectFactory<T> factory,PoolConfig config) {
		if (factory == null) {
			throw new RuntimeException("PoolObjectFactory Is Null!");
		}
		poolMaximumNumber = config.poolMaximumNumber;
		MaximumIdleNumber = config.MaximumIdleNumber;
		MinimumIdleNumber = config.MinimumIdleNumber;
		WHEN_EXHAUSTED_STRATEGY = config.WHEN_EXHAUSTED_STRATEGY;
		switch (WHEN_EXHAUSTED_STRATEGY) {
		case EXHAUSTED_FAIL:
			WHEN_EXHAUSTED_STRATEGY = EXHAUSTED_FAIL;
			break;
		case EXHAUSTED_GROW:
			WHEN_EXHAUSTED_STRATEGY = EXHAUSTED_GROW;
			break;
		case EXHAUSTED_BLOCK:
			WHEN_EXHAUSTED_STRATEGY = EXHAUSTED_BLOCK;
			break;
		default: throw new RuntimeException("WHEN_EXHAUSTED_STRATEGY Mismatching!");
		}
		WAIT_TIME = config.WAIT_TIME;
		ISCLOSE = config.ISCLOSE;
		EVICTOR_WORK = config.EVICTOR_WORK;
		IDLE_RESOURCE_EXIST_TIME = config.IDLE_RESOURCE_EXIST_TIME;
		EVICTOR_WORK_lINTERVAL = config.EVICTOR_WORK_lINTERVAL;
		checkOnBorrow = config.checkOnBorrow;
		checkOnReturn = config.checkOnReturn;
		objectFactory = factory;
		distributePoolObject();
		evictorWork();
	}
	
	/**
	 * 分配池对象,主要有四种分配策略
	 *  1、缓存池存在对象,直接分配对象 
	 *  2、缓存池不存在对象,当前AvailableNumber + LoanNumber < MaxNumber,允许Session(线程)主动创建对象
	 *  3、阻塞模式(超时抛出异常),线程根据配置阻塞一定时间,直到其他线程归还对象到缓存池或者超时抛出异常
	 *  4、当池资源耗尽直接抛出异常
	 */
	private synchronized void distributePoolObject() {
		if(isClose()) {
			throw new RuntimeException("Pool Is Close");
		}
		
		/**
		 * 缓存池资源充足直接分配资源
		 */
		for (;;) {
			if (!_pool.isEmpty() && !_waitQueue.isEmpty()) {
				Session<T> session = _waitQueue.removeFirst();
				Entity<T> entity = _pool.removeFirst();
				session.setPoolObject(entity);
				AvailableNumber--;
				LoanNumber++;
				synchronized (session) {
					session.notify();
				}
			} else {
				break;
			}
		}
		
		/**
		 * 等待队列仍然存在线程,但是缓存当前无对象可用
		 *  1、缓存池容量未达上线,继续创建对象
		 *  2、缓存池耗尽时增长策略未EXHAUSTED_GROW,表示池可以无限增长(高并发严重增加服务器压力)
		 *  LoanNumber表示借出的对象数量,Idle表示空闲对象数量,poolMaximumNumber为缓存池最大容量
		 *  三者之间关系为 LoadNumber + AvailableNumber <= poolMaximumNumber
		 */
		for (;;) {
			if (!_waitQueue.isEmpty() && (LoanNumber + AvailableNumber < poolMaximumNumber)) {
				Session<T> session = _waitQueue.removeFirst();
				session.setAllowCreation(true);
				LoanNumber++;
				synchronized (session) {
					session.notify();
				}
			} else {
				break;
			}
		}
	}

	/**
	 * 缓存池借出对象
	 * @return
	 */
	public T borrowObject() {
		if(isClose()) {
			throw new RuntimeException("Pool Is Closed!");
		}
		Session<T> session = new Session<>();
		synchronized (this) {
			_waitQueue.add(session);
		}
		/**
		 * distributePoolObject优先分配缓存中的对象
		 * 如果资源池对象耗尽但是未达缓存池上线
		 * 允许Session(线程)主动创建"池对象","池对象"交给线程创建优势:
		 * 降低锁占用时间(对象创建可能花费较多时间),提高并发
		 */
		distributePoolObject();
		for(;;) {
			if(isClose()) {
				throw new RuntimeException("Pool Is Close!");
			}
			if(session.getPoolObject() == null) {
				if(!session.allowCreation()) {
					/**
					 * 该策略下,当池资源耗尽,如果Session不被允许创建对象
					 * 直接失败,抛出异常,通知客户端处理
					 */
					if(WHEN_EXHAUSTED_STRATEGY == EXHAUSTED_FAIL) {
						boolean allowCreation = true;
						/**
						 * 防止其他线程调用distributePoolObject
						 * 给当前线程分配池对象或者允许创建"池对象"
						 */
						synchronized (this) {
							if(session.getPoolObject() == null && !session.allowCreation()) {
								allowCreation = false;
								_waitQueue.remove(session);
							}
						}
						if(!allowCreation) {
							throw new RuntimeException("Obtain PoolObject Fail!");
						}
					}
					/**
					 * 默认当"池"资源耗尽时,线程挂起一段时间
					 * 如果超时或者被唤醒时仍然未获取连接抛异常
					 */
					if(WHEN_EXHAUSTED_STRATEGY == EXHAUSTED_BLOCK) {
						try {
							synchronized (session) {
								if(session.getPoolObject() == null && !session.allowCreation()) {
									if(WAIT_TIME <= 0) {
										session.wait();
									}else {
										session.wait(WAIT_TIME);
									}
								}
							}
							/**
							 * 线程超时或者被其他调用distributePoolObject方法唤醒
							 */
							if(isClose()) {
								throw new RuntimeException("Pool Is Closed!");
							}
							boolean allowCreation = true;
							synchronized (this) {
								if(session.getPoolObject() == null && !session.allowCreation()) {
									allowCreation = false;
									_waitQueue.remove(session);
								}
							}
							if(!allowCreation) {
								throw new RuntimeException("Access To Resource Timeouts!");
							}
						} catch (Exception e) {
							synchronized (this) {
								_waitQueue.remove(session);
								if(session.getPoolObject() != null && !session.allowCreation()) {
									LoanNumber--;
									AvailableNumber++;
									try {
										returnObject(session.getPoolObject().getHolderObject());
									}catch (Exception exception) {
										AvailableNumber--;
										try {
											objectFactory.destoryObject(session.getPoolObject().getHolderObject());
										} catch (Exception e2) {
										}
									}
								}
								if(session.allowCreation()) {
									AvailableNumber--;
								}
							}
							distributePoolObject();
						}
					}
					/**
					 * 增长模式,允许Session(线程)主动创建池对象
					 */
					if(WHEN_EXHAUSTED_STRATEGY == EXHAUSTED_GROW) {
						synchronized (this) {
							if(session.getPoolObject() == null && !session.allowCreation()) {
								_waitQueue.remove(session);
								LoanNumber++;
							}
						}
					}
				}
			}
			boolean doAllocate = false;
			if(session.getPoolObject() == null) {
				T poolObject = null;
				try {
					doAllocate = true;
					synchronized (this) {
						LoanNumber++;
						AvailableNumber--;
					}
					poolObject = objectFactory.createObject();
					session.setPoolObject(new Entity<T>(poolObject));
				}catch (Exception e) {
					try {
						objectFactory.destoryObject(poolObject);
					}catch (Exception e2) {
						synchronized (this) {
							LoanNumber--;
						}
						throw e2;
					}
				}
			}
			if(checkOnBorrow) {
				T poolObject = session.getPoolObject().getHolderObject();
				try {
					if(!objectFactory.validateObject(poolObject)) {
						throw new RuntimeException("Pool Object Invalid!");
					}	
				} catch (Exception e) {
					try {
						objectFactory.destoryObject(poolObject);
					}catch (Exception exception) {
					}
					synchronized (this) {
						LoanNumber--;
					}
					if(doAllocate) {
						throw new RuntimeException(e);
					}else {
						synchronized (this) {
							session.clear();
							_waitQueue.add(0,session);
						}
						distributePoolObject();
						continue;
					}
				}
			}
			return session.getPoolObject().getHolderObject();
		}
	}

	/**
	 * 创建对象
	 * 使用工厂创建对象
	 * @return
	 */
	private Entity<T> createPoolObject() {
		if (objectFactory == null) {
			throw new RuntimeException("Object Factory Is Null");
		}
		T poolObject = objectFactory.createObject();
		Entity<T> entity = new Entity<T>(poolObject);
		return entity;
	}
	
	/**
	 * 向缓存中添加"池"对象
	 */
	private void paddingPoolObject() {
		try {
			AvailableNumber++;
			Entity<T> entity = createPoolObject();
			_pool.add(entity);
		}catch (Exception e) {
			AvailableNumber--;
		}
	}
	
	/**
	 * 确保"池"中包含最少的空闲对象
	 * 一定数量的空闲对象保证"池"的性能
	 */
	public void ensureEnoughPoolObject() {
		synchronized (this) {
			while(AvailableNumber + LoanNumber < poolMaximumNumber) {
				if(_pool.size() < MinimumIdleNumber) {
					try {
						paddingPoolObject();
					}catch (Exception e) {
						AvailableNumber--;
					}
				}
			}
		}
	}

	/**
	 * 关闭缓存池 缓存池只允许关闭一次,重复的关闭会抛出异常
	 */
	public void close() {
		if (!isClose()) {
			synchronized (this) {
				Iterator<Entity<T>> iterator = _pool.iterator();
				while (iterator.hasNext()) {
					Entity<T> item = iterator.next();
					destoryPoolObject(item.getHolderObject());
					iterator.remove();
				}
				cleanWaitQueue();
			}
			return;
		}
		try {
			throw new Exception("POOL IS CLOSE!");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	/**
	 * 销毁对象
	 * @param object
	 */
	public void destoryPoolObject(T object) {
		if(isClose()) {
			throw new RuntimeException("Pool Is Close!");
		}
		try {
			objectFactory.destoryObject(object);
		}catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	/**
	 * 清除当前等待队列
	 */
	private void cleanWaitQueue() {
		if(_waitQueue.isEmpty()) {
			return;
		}
		synchronized (this) {
			while (!_waitQueue.isEmpty()) {
				Session<T> latch = _waitQueue.removeFirst();
				try {
					synchronized (latch) {
						latch.notify();
					}
				} catch (Exception e) {
				}
			}
		}
	}
	
	/**
	 * 对象归还线程池
	 * @param poolObject
	 */
	public void returnObject(T poolObject) {
		try {
			if(checkOnReturn) {
				if(!objectFactory.validateObject(poolObject)) {
					throw new Exception("Validate PoolObject Error!");
				}
			}
			synchronized (this) {
				_pool.add(new Entity<T>(poolObject));
				LoanNumber--;
				AvailableNumber++;
			}
		}catch (Exception e) {
			synchronized (this) {
				LoanNumber--;
			}
		}finally {
			distributePoolObject();
		}
	}
	
	/**
	 * 驱逐线程运行,清除空闲对象
	 * 驱逐线程默认为5分钟执行一次清理工作
	 */
	public void evictorWork() {
		if(!EVICTOR_WORK) {
			return;
		}
		if(procurator == null) {
			procurator = new Timer(true);
		}
		Evictor evictor = new Evictor();
		procurator.schedule(evictor,0,EVICTOR_WORK_lINTERVAL);
	}
	
	/**
	 * 驱逐线程,清除缓存池空闲对象
	 * @author 出门左转
	 */
	private class Evictor extends TimerTask{
		
		public void run() {
			try {
				synchronized (this) {
					if(_pool.isEmpty()) {
						return;
					}
					long currentTime = System.currentTimeMillis();
					Iterator<Entity<T>> iterator = _pool.iterator();
					while(iterator.hasNext()) {
						Entity<T> entity = iterator.next();
						if(currentTime - entity.getLastUseTime() > IDLE_RESOURCE_EXIST_TIME) {
							iterator.remove();
							try {
								objectFactory.destoryObject(entity.getHolderObject());
							} catch (Exception e) {
							}finally {
								
							}
						}
					}
				}
				ensureEnoughPoolObject();
				distributePoolObject();
			}catch (Exception e) {
			}
		}
		
		public Evictor getDefaultEvictor() {
			return new Evictor();
		}
	}
	
	/**
	 * 
	 */
	public boolean isClose() {
		return ISCLOSE;
	}

	/**
	 * Session为请求对象
	 * 客户端每次请求获取池对象会创建一个Session对象
	 * @author 出门左转
	 */
	private class Session<T> {
		/**
		 * 标识Session对象是否被允许创建对象
		 * 当池资源耗尽但是未到达池允许创建对象的上限,允许连接主动创建对象
		 */
		private boolean allowCreation = false;
		
		/**
		 * 池对象,该对象可能为池主动创建,可能为连接创建
		 * 运行连接创建对象有点:防止因为创建对象时间过长占用池的“锁”,阻碍其他对象获取池资源
		 */
		private Entity<T> poolObject;

		/**
		 * 返回线程的持有对象
		 * getHolder必须同步防止处于BLOCK模式下其他线程分配了对象
		 * @return
		 */
		public synchronized void setPoolObject(Entity<T> poolObject) {
			this.poolObject = poolObject;
		}

		/**
		 * 设置线程的持有对象
		 * @param holder
		 */
		public synchronized Entity<T> getPoolObject() {
			return poolObject;
		}
		
		/**
		 * 获取Session对象是被否运行创建对象标识
		 * @return
		 */
		public boolean allowCreation() {
			return allowCreation;
		}
		
		/**
		 * 设置Session对象是被否运行创建对象
		 * @param allowCreation
		 * @return
		 */
		public void setAllowCreation(boolean allowCreation) {
			this.allowCreation = allowCreation;
		}
		
		/**
		 * 设置Session内部状态
		 * 当对象主动创建对象失败时,可以进行重试
		 */
		public void clear() {
			poolObject = null;
			allowCreation = false;
		}
	}

	/**
	 * 池对象的包裹对象
	 * 该类的主要作用时包裹对象工厂创建的对象,用来记录对象的生命中周期
	 * @author 出门左转
	 */
	private class Entity<T> {
		/**
		 * 对象最后一次使用的时间
		 * 该值在对象归还到缓存池时被重置,驱逐线程根据此事件决定是否删除对象
		 */
		private long lastUseTime = -1;

		/**
		 * 包裹的对象
		 * 该对象为对象工厂创建
		 */
		private T holderObject;

		/**
		 * 构造函数 默认最后一次使用时间为对象的创建时间
		 */
		public Entity(T element) {
			lastUseTime = System.currentTimeMillis();
			holderObject = element;
		}
		
		/**
		 * 获取池对象最后一次使用时间
		 * @return
		 */
		public long getLastUseTime() {
			return lastUseTime;
		}

		/**
		 * 返回实体持有的对象
		 * @return
		 */
		public T getHolderObject() {
			return holderObject;
		}
	}

}
