package com.lizhenpeng.tortoisecp.pool;

/**
 * 池对象配置
 * @author 出门左转
 */
public class PoolConfig {
	
	/**
	 * 缓存池的默认最大容量为50
	 */
	public int poolMaximumNumber = 50;

	/**
	 * 缓存池中空闲对象的最大数量 显示空闲对象的最大数量
	 * 当并发较低时缓存空闲对象数量较多时会造成资源浪费
	 */
	public int MaximumIdleNumber = 20;

	/**
	 * 缓存池中空闲对象的最小数量 
	 * 缓存池中缓存空闲对象可以在并发提高时减少创建对象花费的时间
	 */
	public int MinimumIdleNumber = 0;

	/**
	 * 定义缓存池资源耗尽时执行的策略 缓存池资源耗尽时直接失败
	 */
	public final int EXHAUSTED_FAIL = 0;

	/**
	 * 定义缓存池资源耗尽时执行的策略 缓存池资源耗尽时继续增长
	 */
	public final int EXHAUSTED_GROW = 1;

	/**
	 * 定义缓存池资源耗尽时执行的策略 缓存池资源耗尽时直接失败
	 * 
	 */
	public final int EXHAUSTED_BLOCK = 2;

	/**
	 * 定义缓存池资源耗尽时执行的策略 
	 * 缓存池资源耗尽时线程阻塞指定的时间
	 * 线程如果被唤醒之后依然没有获取资源,抛出异常
	 */
	public int WHEN_EXHAUSTED_STRATEGY = EXHAUSTED_BLOCK;

	/**
	 * 定义阻塞模式下的线程超时时间
	 * 默认为-1,表示线程不超时,直到被唤醒
	 */
	public long WAIT_TIME = -1;

	/**
	 * 线程池状态标识 
	 * false表示线程池当前正在运行
	 * true表示线程池已经关闭
	 */
	public boolean ISCLOSE = false;

	/**
	 * 清除空闲资源标识,默认开启清除线程
	 */
	public boolean EVICTOR_WORK = true;

	/**
	 * 闲置资源存活时间 
	 * 默认存活时间为5分中,超过存活时间即被清除
	 */
	public int IDLE_RESOURCE_EXIST_TIME = 1000 * 60 * 5;

	/**
	 * 驱逐线程默认运行的时间间隔为5分钟
	 */
	public int EVICTOR_WORK_lINTERVAL = 1000 * 60 * 5;
	
	/**
	 * 对象借出时候检测对象是否可用 并发较高时,使用此功能会影响性能
	 */
	public boolean checkOnBorrow = true;

	/**
	 * 对象归还到池中时检测对象是否可用 并发交高时,使用此功能会影响性能
	 */
	public boolean checkOnReturn =true;
	
	/**
	 * 获取默认的配置对象
	 * @return
	 */
	public static PoolConfig getDefaultConfig() {
		return new PoolConfig();
	}
}
